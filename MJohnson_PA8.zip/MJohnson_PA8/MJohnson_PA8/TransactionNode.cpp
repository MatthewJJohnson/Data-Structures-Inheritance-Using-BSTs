#include "TransactionNode.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

TransactionNode::TransactionNode(const string &newData,const int &newUnits) : Node(newData)
{
	this->mUnits = newUnits;
}

//not virtual destructor, implicitly called
TransactionNode::~TransactionNode()
{
	//cout << "inside destructor for teh TransactionNode" << endl;
}

//getter, get number of units
int TransactionNode::getUnits()
{
	return mUnits;
}

//setter, set units
void TransactionNode::setUnits(const int &newUnits)
{
	mUnits = newUnits;
}

//function, prints data when called. C++ will 
//choose this over Node's print data 
void TransactionNode::printData()
{
	cout << mData << endl; //same as calling Node::printData();
	cout << mUnits << endl;
}