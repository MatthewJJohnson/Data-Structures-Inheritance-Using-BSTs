#pragma once
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

#include <iostream>
#include <fstream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;
using std::ios;

class Node
{
public:
	//construct
	Node(const string &newData = "");

	//destruct
	virtual ~Node(); //virtual destructor

	//get
	string getData();
	Node *& getLeft();
	Node *& getRight();

	//set
	void setLeft(Node * const newLeft);
	void setRight(Node * const newRight);
	void setData(const string &newData);

	//func
	virtual void printData() = 0; //pure virtual function to be overwritten
								//now an abstract class
protected://data members
	string mData;
	Node *mpLeft;
	Node *mpRight;
};