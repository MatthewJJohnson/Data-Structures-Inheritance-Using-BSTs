#pragma once
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

#include <iostream>
#include <fstream>
#include <string>

#include "Node.h"

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;
using std::ios;

class TransactionNode : public Node //has transaction node AND node info
{						//inheritance
public:
	//constructor
	TransactionNode(const string &newData = "",const int &newUnits = 0);
	//destructor
	~TransactionNode();

	//set
	int getUnits();

	//get
	void setUnits(const int &newUnits);

	void printData();//overwrites virtual function to print units

private://data members
	int mUnits;
};
