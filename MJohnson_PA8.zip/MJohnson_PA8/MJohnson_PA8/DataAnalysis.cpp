#include "DataAnalysis.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

//opens file stream and calls line parser
//post: file stream is closed
void DataAnalysis::loadFile()
{
	mCsvStream.open("data.csv");
	lineParser();
	mCsvStream.close();
}

//PRE: file must be open
//post: nodes must be inserted in both trees
//this function places information into the nodes into BOTH bst's from the open file
void DataAnalysis::lineParser()
{
	int iterate = 0;
	char Type[100] = "";
	char EatIdentity[1000] = "";
	char Name[100] = "";
	char ReadUnits[100] = "";
	int Units = 0;
	while (iterate < 14)//poor practice to not use EOF, but meh
	{
		if (iterate == 0)
		{
			mCsvStream.getline(EatIdentity, 1000, '\n');//eat the entire first line
		}
		else
		{
			mCsvStream.getline(ReadUnits, 100, ',');
			Units = atoi(ReadUnits); //convert to integer
			mCsvStream.getline(Name, 100, ',');
			mCsvStream.getline(Type, 100, '\n');
			if (Type[0] == 'P')//can only compare index 0
			{
				mTreePurchased.insert(Name, Units); //add
			}
			else if (Type[0] == 'S')//can only compare index 0
			{
				mTreeSold.insert(Name, Units);//add
			}
		}
		iterate++;
	}
}

//PRE: Trees were loaded
//this function prints both BST trees
void DataAnalysis::TraverseTreePrinter()
{
	cout << "Printing All Items Purchased..." << endl;
	mTreePurchased.inOrderTraversal();
	cout << "\nPrinting All Items Sold..." << endl;
	mTreeSold.inOrderTraversal();
}

//PRE: Trees were loaded
//this function prints both BST stats
void DataAnalysis::TransactionStats()
{
	cout << "\nThese were found to be the most purchased and least purchased." << endl;
	cout << mTreePurchased.findLargest(mTreePurchased.getRoot()) << endl;
	cout << mTreePurchased.findSmallest(mTreePurchased.getRoot()) << endl;

	cout << "\nThese were found to be the most sold and least sold." << endl;
	cout << mTreeSold.findLargest(mTreeSold.getRoot()) << endl;
	cout << mTreeSold.findSmallest(mTreeSold.getRoot()) << endl << endl;
}

//this function runs the program
void DataAnalysis::runAnalysis()
{
	loadFile();
	TraverseTreePrinter();
	TransactionStats();
}

//overoaded operator used to print nodes using <<
//i could also use the print fuctions, but I felt
//I needed practice using Overloaded operators.
ostream & operator<<(ostream &lhs, TransactionNode &rhs)
{
	lhs << rhs.getData() << ": ";
	lhs << rhs.getUnits();
	return lhs;
}