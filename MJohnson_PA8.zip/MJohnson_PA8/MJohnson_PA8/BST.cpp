#include "BST.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

BST::BST()
{
	mpRoot = nullptr;
}

//public destructor, calls upon private destroytree
//this way pointer info is hidden
BST::~BST()
{
	destroyTree(this->mpRoot);
}

//getter, gets the top of the tree
Node * BST::getRoot() const
{
	return mpRoot;
}

// the contents of newRoot can't be modified, but
// the Node can be modified!
void BST::setRoot(Node * const newRoot)
{
	mpRoot = newRoot;
}

//destroys the tree
//will implicitly call destructors
//PRE: destructor has been called
void BST::destroyTree(Node *pTree)
{
	if (pTree != nullptr)//base case the current pointer is NULL
	{
		destroyTree(pTree->getLeft()); //this three line process is a "Post-Order Traversal.
									   //get left is returning a reference to a pointer, the first node on the left side.
		destroyTree(pTree->getRight()); //now the first node on the right after the first instance on the left (if it exists, if not ptree is now null)
		//cout << "Deleting: "<< pTree->getData() << endl;
		delete pTree;
	}
}

//public traversal, calls upon private traversal
//this way pointer info is hidden
void BST::inOrderTraversal()
{
	inOrderTraversal(this->mpRoot);
}

//pre: public insert is called
//post: call stack is returned to enter state
//the entire tree is traversed and printed both the name and the number of units
void BST::inOrderTraversal(Node *pTree)
{
	//base case
	if (pTree != nullptr) //first null pointer will be all the way left
	{
		//1. go left
		inOrderTraversal(pTree->getLeft());
		//2. process the node (print stuff)
		cout << pTree->getData() << ": "; //colon inserted before units "(String: Int)/n"
		cout << (dynamic_cast<TransactionNode *>(pTree))->getUnits() << endl;
		//3. go right
		inOrderTraversal(pTree->getRight());
	}

}

//public insert, calls upon private insert
//this way pointer info is hidden
void BST::insert(const string & newData, const int &newUnits) //function prototype is a reference to an integer that is considered constant
{
	insert(this->mpRoot, newData, newUnits);
}

//private, uses recursion
//pre: public insert is called
//post: call stack is returned to its enter state
void BST::insert(Node *& pTree, const string &newData,const int & newUnits) //pTree is a reference to a pointer to a node
													//since it is a reference to a pointer, changes will be retained outside of this function. The reference replaces a double star
{
	if (pTree == nullptr)//base case
	{
		//making node
		TransactionNode *pMem = nullptr;
		pMem = new TransactionNode(newData, newUnits);
		//connecting to tree
		pTree = pMem;
	}
	else if (newUnits > (dynamic_cast<TransactionNode *>(pTree))->getUnits())//direction goes left in the tree
	{					//Node is an abstract class with virtual functions making it polymorphic
						//We can safely use dynamic_cast which will ensure safe pointer manipulation
		insert(pTree->getRight(), newData, newUnits);
	}
	else if (newUnits < (dynamic_cast<TransactionNode *>(pTree))->getUnits())//direction goes right in the tree
	{					//Node is an abstract class with virtual functions making it polymorphic
						//We can safely use dynamic_cast which will ensure safe pointer manipulation
		insert(pTree->getLeft(), newData, newUnits);
	}
	else //newdata == current node's data
	{
		cout << "Tried to insert a Duplicate" << endl;
	}
}

//pre: file has been loaded
//finds the smallest node (based on units) 
TransactionNode & BST::findSmallest(Node *pTree)
{
	if (pTree == nullptr)
	{
		return (dynamic_cast<TransactionNode &>(*pTree));
	}
	else if (pTree != nullptr)
	{
		while (pTree->getLeft() != nullptr)
		{
			pTree = pTree->getLeft();
		}
		return (dynamic_cast<TransactionNode &>(*pTree));
	}
}

//pre: file has been loaded
//finds the Largest node (based on units) 
TransactionNode & BST::findLargest(Node *pTree)
{
	if (pTree == nullptr)
	{
		return (dynamic_cast<TransactionNode &>(*pTree));
	}
	else if (pTree != nullptr)
	{
		while (pTree->getRight() != nullptr)
		{
			pTree = pTree->getRight();
		}
		return (dynamic_cast<TransactionNode &>(*pTree));
	}
	
}