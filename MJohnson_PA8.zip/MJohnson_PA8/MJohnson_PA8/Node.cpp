#include "Node.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

//destructor with default arguments, required by andy for this PA
Node::Node(const string &newData)
{
	mData = newData;
	mpLeft = nullptr;
	mpRight = nullptr;
}

//virtual destructor is implicitly called
Node::~Node()
{
	//cout << "inside virtual destructor for teh node" << endl;
}

//getter, get left leaflet
Node *& Node::getLeft() //returns a reference to a pointer
{
	return mpLeft;
}

//getter, get right leaflet
Node *& Node::getRight() //returns a reference to a pointer
{
	return mpRight;
}

//getter, get the data string from the node
string Node::getData() 
{
	return mData;
}

//setter, set left leaflet pointer
void Node::setLeft(Node * newLeft)
{
	mpLeft = newLeft;
}

//setter, set right leaflet pointer
void Node::setRight(Node * newRight)
{
	mpRight = newRight;
}

//setter, set data in the node
void Node::setData(const string &newData)
{
	mData = newData;
}

//print the data in the node
void Node::printData()
{
	cout << mData << endl;
}