#pragma once
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

#include <iostream>
#include <fstream>
#include <string>

#include "BST.h"

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;
using std::ios;

class DataAnalysis
{
public:
	void runAnalysis(); //run program

private:
	ifstream mCsvStream; //file stream
	BST mTreeSold; 
	BST mTreePurchased;
	void loadFile(); //open file, calls line parser
	void lineParser(); //seperate lines and place them in BST's
	void TraverseTreePrinter(); //print trees
	void TransactionStats(); //get and print stats
};
//overloaded function to print from TransactionStats()
ostream & operator<<(ostream &lhs, TransactionNode &rhs);