#include "DataAnalysis.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
				into two different BST's. This program also calculates the least and most 
				purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

int main(void)
{
	DataAnalysis obj; //declaring object
	obj.runAnalysis(); //run program from one function call
	return 0;
}