#pragma once
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 122; Lab Section 1
* Programming Assignment: PA8
* Date:   11/15/2016
* Colloaborator(s):
* Description: This reads a file containing sales information and places that information
into two different BST's. This program also calculates the least and most
purchased in each BST. Inheritance is used.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

#include <iostream>
#include <fstream>
#include <string>

#include "Node.h"
#include "TransactionNode.h"

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;
using std::ios;

class BST 
{
public:
	BST();
	~BST();

	Node *getRoot() const;
	void setRoot(Node * const newRoot);

	// will call on private function()
	void insert(const string &newData, const int &newUnits);
	void inOrderTraversal();

	TransactionNode & findSmallest(Node *pTree); //find least purchased/sold
	TransactionNode & findLargest(Node *pTree);//find most purchased/sold

private:
	Node * mpRoot;
	void destroyTree(Node *pTree);//we do not need a reference, only a pointer to the memory
	void inOrderTraversal(Node *pTree);//just want the pointer not the reference, I am not changing anything
	void insert(Node *& pTree, const string &newData, const int &newUnits);
};
